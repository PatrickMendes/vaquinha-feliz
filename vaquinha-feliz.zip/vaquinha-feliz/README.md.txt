# 🐄 Vaquinha Feliz - Jogo Web

Bem-vindo ao **Vaquinha Feliz**, um jogo web divertido onde você cuida de uma vaquinha! Alimente, conforte e ordenhe para acumular leite. Cuidado para que ela não fique doente!

## 🎮 Como jogar

- 🥩 **Alimente** a vaquinha para manter a fome sob controle  
- 💆 **Conforte** para que ela fique feliz  
- 🥛 **Ordenhe** para acumular leite e comprar upgrades  
- 🛒 Compre **ração premium** para alimentá-la melhor!  
- 🌧️ Fique atento a eventos como **chuva**, que afetam o conforto

## 🖥️ Acesse o jogo online

👉 [Clique aqui para jogar!](https://SEU-USUARIO.github.io/vaquinha-feliz)

## 📱 Compatível com celular

Feito com HTML5, CSS3 e JavaScript puro, 100% responsivo.

---

Feito com ❤️ por [Seu Nome ou @usuario]
